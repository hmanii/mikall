# mikrotikTerraform
Terraform code to config Mikrotik
